export interface Image {
  id: string;
  image: string;
}
