import { LoaderService } from './services/loader.service';
import { Image } from './model/image';
import { GalleryService } from './services/gallery.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'indemn-mariaj';

  img: Image = {
    id: '',
    image: ''
  };

  isLoaderOpen = false;

  constructor(private image: GalleryService, private loader: LoaderService, private router: Router) { }

  ngOnInit(): void {
    // this.getLoader();
    this.image.selectImg.subscribe(data => {
      this.img = this.image.img;
    });
    this.loader.load.subscribe(data => {
      this.isLoaderOpen = this.getLoader();
    });
  }

  getLoader(): boolean {
    return this.loader.getLoader();
  }

  isImageSelected(): boolean {
    return this.img.id !== '';
  }

  closeImageView(): void {
    this.img = {
      id: '',
      image: ''
    };
  }

  disableScrolling() {
    const x = window.scrollX;
    const y = window.scrollY;
    window.onscroll = () => { window.scrollTo(x, y); };
  }

  enableScrolling() {
    window.onscroll = () => { };
  }

}
