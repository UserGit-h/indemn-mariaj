import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
import { SendMailService } from '../services/send-mail.service';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.scss']
})
export class ContactComponent implements OnInit {

  profileForm = new FormGroup({
    name: new FormControl(''),
    email: new FormControl(''),
    message: new FormControl(''),
  });

  message = '';

  constructor(public mail: SendMailService) { }

  ngOnInit(): void {
  }

  onSubmit(): void {
    if (this.profileForm.value.name !== '' && this.profileForm.value.email !== '' && this.profileForm.value.message !== '') {
      console.log(this.profileForm.value);
      const data = {
        email: this.profileForm.value.email,
        subject: this.profileForm.value.name,
        text: this.profileForm.value.message
      };
      console.log(typeof data.email);
      this.mail.sendMail(data).subscribe((response) => {
        this.profileForm = new FormGroup({
          name: new FormControl(''),
          email: new FormControl(''),
          message: new FormControl(''),
        });

        console.log(response);
        this.message = response.message;

        setTimeout(() => {
          this.message = '';
        }, 3000);
      });
    }
  }

}
