import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SendMailService {

  url = 'https://indemn-mariaj.herokuapp.com/email';


  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: 'my-auth-token'
    })
  };

  constructor(private http: HttpClient) { }

  sendMail(content: any): Observable<any> {
    console.log(content);
    return this.http.post<any>(this.url, content, this.httpOptions);
  }
}
