import { Image } from './../model/image';
import { Injectable, EventEmitter, Output } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class GalleryService {
  @Output() public selectImg = new EventEmitter<any>();

  img: Image = {
    id: '',
    image: ''
  };

  images: Image[] = [
    {
      id: '1',
      image: '../../assets/img/four-image.jpg'
    },
    {
      id: '2',
      image: '../../assets/img/first-image.jpg'
    },
    {
      id: '3',
      image: '../../assets/img/1.jpg'
    },
    {
      id: '4',
      image: '../../assets/img/six-image.jpg'
    },
    {
      id: '5',
      image: '../../assets/img/3.jpg'
    },
    {
      id: '6',
      image: '../../assets/img/five-image.jpg'
    },
    {
      id: '7',
      image: '../../assets/img/4.jpg'
    },
    {
      id: '8',
      image: '../../assets/img/5.jpg'
    },
    {
      id: '9',
      image: '../../assets/img/6.jpg'
    },
    {
      id: '10',
      image: '../../assets/img/second-image.jpg'
    },
    {
      id: '11',
      image: '../../assets/img/8.jpg'
    },
    {
      id: '12',
      image: '../../assets/img/9.jpg'
    },
    {
      id: '13',
      image: '../../assets/img/10.jpg'
    },
    {
      id: '14',
      image: '../../assets/img/11.jpg'
    },
    {
      id: '15',
      image: '../../assets/img/12.jpg'
    },
    {
      id: '16',
      image: '../../assets/img/13.jpg'
    },
    {
      id: '17',
      image: '../../assets/img/14.jpg'
    },
    {
      id: '18',
      image: '../../assets/img/15.jpg'
    },
    {
      id: '19',
      image: '../../assets/img/16.jpg'
    },
    {
      id: '20',
      image: '../../assets/img/17.jpg'
    },
    {
      id: '21',
      image: '../../assets/img/18.jpg'
    },
    {
      id: '22',
      image: '../../assets/img/19.jpg'
    },
    {
      id: '23',
      image: '../../assets/img/20.jpg'
    },
    {
      id: '24',
      image: '../../assets/img/24.jpg'
    },
    {
      id: '25',
      image: '../../assets/img/25.jpg'
    },
    {
      id: '26',
      image: '../../assets/img/26.jpg'
    },
    {
      id: '27',
      image: '../../assets/img/27.jpg'
    },
    {
      id: '28',
      image: '../../assets/img/28.jpg'
    },
    {
      id: '29',
      image: '../../assets/img/29.jpg'
    },
    {
      id: '30',
      image: '../../assets/img/30.jpg'
    },
    {
      id: '31',
      image: '../../assets/img/31.jpg'
    },
    {
      id: '32',
      image: '../../assets/img/32.jpg'
    },
    {
      id: '33',
      image: '../../assets/img/33.jpg'
    },
    {
      id: '34',
      image: '../../assets/img/34.jpg'
    },
    {
      id: '35',
      image: '../../assets/img/35.jpg'
    }
  ];

  constructor() { }

  selectImage(id: string): void {
    this.images.forEach(image => {
      if (image.id === id) {
        this.img = image;
      }
    });
  }

  getImage(): Image[] {
    return this.images;
  }
}
