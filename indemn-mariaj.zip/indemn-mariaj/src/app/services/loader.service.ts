import { Injectable, EventEmitter, Output } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoaderService {
  // tslint:disable-next-line: no-output-native
  @Output() public load = new EventEmitter<any>();

  isLoaderOpen = false;

  constructor() { }

  changeLoader(condition: boolean): void {
    this.isLoaderOpen = condition;
  }

  getLoader(): boolean {
    return this.isLoaderOpen;
  }
}
