import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-offerte-si-servicii',
  templateUrl: './offerte-si-servicii.component.html',
  styleUrls: ['./offerte-si-servicii.component.scss']
})
export class OfferteSiServiciiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
