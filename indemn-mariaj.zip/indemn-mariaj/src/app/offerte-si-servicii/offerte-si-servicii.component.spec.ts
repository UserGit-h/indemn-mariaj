import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OfferteSiServiciiComponent } from './offerte-si-servicii.component';

describe('OfferteSiServiciiComponent', () => {
  let component: OfferteSiServiciiComponent;
  let fixture: ComponentFixture<OfferteSiServiciiComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OfferteSiServiciiComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OfferteSiServiciiComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
