import { Component, OnInit, HostListener, OnChanges } from '@angular/core';
import { trigger, transition, state, animate, style } from '@angular/animations';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss'],
  animations: [
    trigger('showHide', [
      state('leave', style({ height: '0px', visibility: 'hidden' })),
      state('enter', style({ height: '300px', visibility: 'visible' })),
      transition('leave <=> enter', [
        animate('0.5s')
      ])
    ])
  ]
})
export class NavBarComponent implements OnInit, OnChanges {

  navState = 'leave';

  constructor() { }

  ngOnInit(): void {
  }

  @HostListener('window:click', ['$event.target'])

  ngOnChanges(): void {
    window.addEventListener('click', (event) => {
      const name = event.target as HTMLElement;
      if (name.tagName.toLowerCase() === 'a') {
        this.navState = 'leave';
      }
    });
  }

  showNav() {
    this.navState = (this.navState === 'leave') ? 'enter' : 'leave';
  }

  detectMobile() {
    return window.innerWidth > 900;
  }

}
