import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortofoliuComponent } from './portofoliu.component';

describe('PortofoliuComponent', () => {
  let component: PortofoliuComponent;
  let fixture: ComponentFixture<PortofoliuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortofoliuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortofoliuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
