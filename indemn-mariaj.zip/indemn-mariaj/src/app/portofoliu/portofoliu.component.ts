import { LoaderService } from './../services/loader.service';
import { Image } from './../model/image';
import { GalleryService } from './../services/gallery.service';
import { Component, OnInit } from '@angular/core';
import { style } from '@angular/animations';

@Component({
  selector: 'app-portofoliu',
  templateUrl: './portofoliu.component.html',
  styleUrls: ['./portofoliu.component.scss']
})
export class PortofoliuComponent implements OnInit {

  isImageSectionSelected = true; // e folosit pentru a verifica daca imaginea este selectata

  activeLink = true; // pentru a schimba clasa la linkuri (poze-video)

  constructor(private gallery: GalleryService, private loader: LoaderService) { }

  ngOnInit(): void {
    this.onWait();
    this.gallery.getImage();
  }


  onWait(): void { // asteapta sa se incarce imaginile inainte de a afisa tot
    setTimeout(() => {
      this.loader.changeLoader(true);
      this.loader.load.emit('emit');
    }, 10);
    setTimeout(() => {
      this.onLoadImages();
    }, 3000);
  }

  onLoadImages(): void {  // incarca imaginile de pe serviciu
    this.gallery.getImage().forEach(image => {
      let img: any;
      if (image.id === '29') {
        img = new Image(300);
        img.style.width = 'auto';
        img.style.height = '100%';
      } else if (image.id !== '35') {
        img = new Image(300);
      } else if (image.id === '35') {
        img = new Image(300, 300);
        img.style.width = '100%';
        img.style.height = 'auto';
      }
      img.src = image.image;
      img.style.cursor = 'pointer';
      img.addEventListener('click', () => {
        this.onImageClick(image.id);
      });
      const box = document.createElement('div');
      box.className = 'box';
      box.style.width = '300px';
      box.style.height = '300px';
      box.style.display = 'flex';
      box.style.justifyContent = 'center';
      box.style.alignItems = 'center';
      box.style.margin = '20px 20px';
      box.appendChild(img);

      // am folosit aceste if-uri pentru ca am aranjat pozele cate 3 pe un rand, ca sa fie mai elegante

      if (image.id === '1' || image.id === '2' || image.id === '3') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('first').appendChild(box);
      } else if (image.id === '4' || image.id === '5' || image.id === '6') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('second').appendChild(box);
      } else if (image.id === '7' || image.id === '8' || image.id === '9') {
        img.style.width = 'auto';
        img.style.height = '100%';
        document.getElementById('third').appendChild(box);
      } else if (image.id === '10' || image.id === '11' || image.id === '12') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('four').appendChild(box);
      } else if (image.id === '13' || image.id === '14' || image.id === '15') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('five').appendChild(box);
      } else if (image.id === '16' || image.id === '17' || image.id === '18') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('six').appendChild(box);
      } else if (image.id === '19' || image.id === '20' || image.id === '21') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('seven').appendChild(box);
      } else if (image.id === '22' || image.id === '23' || image.id === '24') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('eight').appendChild(box);
      } else if (image.id === '25' || image.id === '26' || image.id === '27') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('nine').appendChild(box);
      } else if (image.id === '28' || image.id === '30' || image.id === '31') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('ten').appendChild(box);
      } else if (image.id === '32' || image.id === '33' || image.id === '34') {
        img.style.width = '100%';
        img.style.height = 'auto';
        document.getElementById('eleven').appendChild(box);
      } else if (image.id === '29' || image.id === '35') {
        document.getElementById('twelve').appendChild(box);
      }
    });

    this.onChangeLoader();
  }

  onChangeLoader(): void {
    this.loader.changeLoader(false);
    this.loader.load.emit('emit');
  }

  onImageClick(pictureName: string): void { // vezi o imagine mai mare
    this.gallery.selectImage(pictureName); // select image with click
    this.gallery.selectImg.emit('hello');
  }

  changeView(type: string): void { // schimba perspectiva
    if (type === 'videoclipuri') {
      this.activeLink = false;
      this.isImageSectionSelected = false;
    } else if (type === 'poze') {
      this.activeLink = true;
      this.isImageSectionSelected = true;
      this.onWait();
    }
  }

}
